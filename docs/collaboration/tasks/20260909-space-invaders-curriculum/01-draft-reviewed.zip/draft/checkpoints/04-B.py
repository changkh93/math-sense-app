import pygame
import random

pygame.init()

SCREEN_WIDTH = 1200
SCREEN_HEIGHT = 700
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption('우주 방어대')

FPS = 60
clock = pygame.time.Clock()

# --- 클래스 설계도 ---
class Mission:
    pass

class Scout(pygame.sprite.Sprite):
    def __init__(self, pulses):
        super().__init__()
        self.image = pygame.transform.smoothscale(
            pygame.image.load('assets/scout.png').convert_alpha(), (64, 64)
        )
        self.rect = self.image.get_rect()
        self.rect.centerx = SCREEN_WIDTH // 2
        self.rect.bottom = SCREEN_HEIGHT
        self.lives = 5
        self.velocity = 8
        self.pulses = pulses
        self.shoot_sound = pygame.mixer.Sound('assets/scout_pulse.ogg')

    def update(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and self.rect.left > 0:
            self.rect.x -= self.velocity
        if keys[pygame.K_RIGHT] and self.rect.right < SCREEN_WIDTH:
            self.rect.x += self.velocity

    def fire(self):
        if len(self.pulses) < 2:
            self.shoot_sound.play()
            ScoutPulse(self.rect.centerx, self.rect.top, self.pulses)

    def reset(self):
        self.rect.centerx = SCREEN_WIDTH // 2

class Raider(pygame.sprite.Sprite):
    pass

class ScoutPulse(pygame.sprite.Sprite):
    def __init__(self, x, y, pulse_group):
        super().__init__()
        self.image = pygame.Surface((4, 16), pygame.SRCALPHA)
        self.image.fill((78, 240, 255))
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.centery = y
        self.velocity = 10
        pulse_group.add(self)

    def update(self):
        self.rect.y -= self.velocity

class RaiderPulse(pygame.sprite.Sprite):
    pass

# --- 스프라이트 그룹 및 객체 생성 ---
scout_pulses = pygame.sprite.Group()
raider_pulses = pygame.sprite.Group()

scouts = pygame.sprite.Group()
scout = Scout(scout_pulses)
scouts.add(scout)

raiders = pygame.sprite.Group()

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                scout.fire()

    screen.fill((9, 17, 37))

    scouts.update()
    scouts.draw(screen)

    scout_pulses.update()
    scout_pulses.draw(screen)

    pygame.display.update()
    clock.tick(FPS)

pygame.quit()
