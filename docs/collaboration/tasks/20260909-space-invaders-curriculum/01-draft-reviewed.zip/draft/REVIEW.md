# 우주 방어대 (Space Invaders) 커리큘럼 검수 보고서 (REVIEW.md)

- 작업 ID: `20260909-space-invaders-curriculum/01`
- 담당자: 교육 콘텐츠 집필자 (Antigravity / Gemini 3.8 Flash)
- 프로젝트: `math-sense-app`
- 기준 커밋: `9da58446475546b67435f0980174d75443d57682`

---

## 1. Udemy 원강의 vs 우주 방어대 커리큘럼 순서 대조표

원본 강의 자막(52~60강) 및 목차에서 확인된 실제 도입 순서와 본 커리큘럼의 체크포인트 및 Data Log 단원 구성을 1:1 대조하였습니다. 완성 소스 파일의 물리적 함수 배치 순서로 재배치하지 않고, 실제 교육이 진행되는 점진적 제작 순서를 완벽하게 준수했습니다.

| 유닛 | 원강의 / lecture ID | 확인된 강의 도입 순서 | 우주 방어대 커리큘럼 단원 및 체크포인트 | 순서 준수 여부 및 특징 |
|---|---|---|---|---|
| **01** | 51 Preview / 27597170 | 게임 목표·조작·적 편대·기체·라운드 규칙 이해 | `data-log/01.md` / `checkpoints/01-A.py` | 일치 (영상 대신 스튜디오 준비 안내, 라이브러리 초기화 검증) |
| **02** | 52 Setup / 27597174 | 화면/루프/FPS/QUIT → 첫 실행 → 5개 클래스 pass 뼈대 | `data-log/02.md` / `checkpoints/02-A, 02-B, 02-C.py` | 일치 (화면 열기 → 색상 시험 → 5대 클래스 pass 선언) |
| **03** | 53 Player Class / 27597176 | 그룹 생성/연결 → 플레이어 Sprite/이미지/위치/속도/소리 → 좌우 이동/경계 → reset | `data-log/03.md` / `checkpoints/03-A, 03-B, 03-C.py` | 일치 (Scout 화면 배치 → 좌우 연속 이동 및 clamp → 위치 reset) |
| **04** | 54 Player Bullet Class / 27597182 | 탄환 생성/등록 → y감소 → fire 연결 → 2발 제한 버그 관찰 → kill로 해결 | `data-log/04.md` / `checkpoints/04-A, 04-B, 04-C.py` | 일치 (탄환 발사 → 2발 제한 후 멈춤 관찰 → rect.bottom<0 kill() 해결) |
| **05** | 55 Alien Class / 27597186 | 적 Sprite/이미지/좌표기억/방향1/속도/무작위 발사조건/reset (편대 미생성) | `data-log/05.md` / `checkpoints/05-A.py` | 일치 (Raider 설계도 완성, 편대 미생성 상태 이유 설명) |
| **06** | 56 Alien Bullet Class / 27597190 | 임시 10개 편대 먼저 → 적 탄환 하강 → kill 연결 → 비교 연산 오류 진단 | `data-log/06.md` / `checkpoints/06-A, 06-B, 06-C.py` | 일치 (임시 10기 출격 → RaiderPulse 발사 → top>SCREEN_HEIGHT kill 해결) |
| **07** | 57 Game Class 1 / 27597194 | 사령부 객체/사운드/도현체 폰트 → HUD 표시 → 11×5 편대 생성, 임시 편대 삭제 | `data-log/07.md` / `checkpoints/07-A, 07-B.py` | 일치 (Mission 초기화 및 HUD/방어선 → 11x5 전면 편대 출격, 임시 삭제) |
| **08** | 58 Game Class 2 / 27597200 | 전원 벽면 도달 여부 먼저 결정 → 일괄 하강/반전 → 최후 방어선 침범 판정 | `data-log/08.md` / `checkpoints/08-A, 08-B.py` | 일치 (2단계 편대 통솔 shift_raiders → breach 경보 및 기체 감소) |
| **09** | 59 Game Class 3 / 27597202 | 탄환 비우기 → 플레이어/적 위치 reset → 일시정지와 Enter 대기 (State 개선) | `data-log/09.md` / `checkpoints/09-A, 09-B.py` | 일치 (웹 호환 mission.state 아키텍처 도입 → check_game_status 전장 정돈) |
| **10** | 60 Game Class 4 / 27597204 | **전체 reset 먼저** → **그다음 충돌(격추/피격)** → **마지막 라운드 완료/보너스** | `data-log/10.md` / `checkpoints/10-A, 10-B, 10-C.py`, `final-main.py` | 일치 (reset_game 먼저 → check_collisions 다음 → check_round_completion 완성) |

---

## 2. 실행 지점(Checkpoints) 누락 및 점진성 점검

총 24개의 완전하고 누적된 Python 파일이 `draft/checkpoints/`에 작성되었으며, 각 단계는 독자가 코드를 추측할 필요 없이 이전 파일에서 설명된 수정 사항만을 순서대로 적용하여 정확히 일치하도록 설계되었습니다.

- **01-A.py**: 라이브러리 및 환경 점검 (4줄)
- **02-A.py**: 1200x700 화면 생성, FPS 60 클럭, 메인 루프, QUIT 이벤트 처리, 짙은 남색(9, 17, 37) 배경 칠하기
- **02-B.py**: 배경 색상 교체 시험 (15, 45, 65)
- **02-C.py**: 5개 클래스(Mission, Scout, Raider, ScoutPulse, RaiderPulse)의 `pass` 뼈대 선언
- **03-A.py**: `Scout.__init__` 이미지/크기(64x64)/위치/생명(5)/속도(8)/사운드 로드, 스프라이트 그룹 생성 및 루프 내 draw
- **03-B.py**: `Scout.update` 좌우 연속 키 입력(`pygame.key.get_pressed`) 및 화면 경계 clamp
- **03-C.py**: `Scout.reset` 가로 중앙 복원 메서드 추가
- **04-A.py**: `ScoutPulse` Surface(4, 16) 생성, 상향 이동, `Scout.fire` 및 스페이스바 이벤트 연결
- **04-B.py**: `Scout.fire` 내 `len(self.pulses) < 2` 2발 제한 추가 (화면 밖 영구 발사 불가 버그 관찰 지점)
- **04-C.py**: `ScoutPulse.update` 내 `if self.rect.bottom < 0: self.kill()` 소멸 로직 추가 (버그 해결)
- **05-A.py**: `Raider` 클래스 초기화(56x48), 시작 좌표(starting_x, starting_y) 저장, 방향1, 무작위 사격 조건, update 연결 (화면 미출현 이유 설명)
- **06-A.py**: 임시 10마리 일렬 편대 for 루프 생성 및 오른쪽 행진 관찰
- **06-B.py**: `RaiderPulse` Surface(4, 16) 산호빛 붉은색 탄환 생성, 하강 이동, `Raider.fire` 연결
- **06-C.py**: `RaiderPulse.update` 내 `if self.rect.top > SCREEN_HEIGHT: self.kill()` 올바른 바닥 소멸 로직 적용
- **07-A.py**: `Mission` 클래스 초기화, 4개 사운드 및 도현체(28pt) 로드, 상단 HUD 및 붉은 방어선(y=600) 렌더링
- **07-B.py**: `Mission.start_new_round` 11열×5행(55기) 편대 생성, 출격음(`wave_ready.ogg`), 임시 10기 삭제 및 정식 호출
- **08-A.py**: `Mission.shift_raiders` 편대 전원 벽면 도달 여부 1단계 검사 및 10px 일괄 강하/방향 반전 2단계 실행
- **08-B.py**: 최후 방어선 침범(`rect.bottom >= SCREEN_HEIGHT - 100`) 감지, 경보음(`line_alert.ogg`) 및 기체 1 차감
- **09-A.py**: 웹 브라우저 호환 `mission.state` 상태 머신 아키텍처, 반투명 오버레이 안내창, Enter 키 입력 분기
- **09-B.py**: `Mission.check_game_status` 양쪽 탄환 `empty()`, 우주선/적 `reset()` 위치 복원, 생명 체크
- **10-A.py**: [순서 1] `Mission.reset_game` 전체 리셋 먼저 구현 (최종점수 안내, 0점/1라운드/5기체 초기화)
- **10-B.py**: [순서 2] `Mission.check_collisions` 충돌 구현 (groupcollide 격추음/+100점, spritecollide 피격음/생명차감)
- **10-C.py**: [순서 3] `Mission.check_round_completion` 라운드 정복 완료 (전멸 감지, 1000*라운드 보너스, 속도 가속 편대)
- **final-main.py**: 완성된 최종 소스 코드 (10-C와 100% 동일한 로직, 깔끔한 주석 및 블록 구분)

---

## 3. 의도적 오류/미완성과 해결 위치 대조

학생들이 강의 과정에서 겪는 혼란과 의도된 미완성 상태를 숨기지 않고 명확한 교육적 원리로 다루었습니다.

1. **02유닛 5개 클래스 선언 후 화면 불변 현상**
   - 증상: 클래스를 5개나 만들었는데 화면에 아무것도 나타나지 않음.
   - 해결: 클래스는 도면(설계도)일 뿐이며, 객체(인스턴스)를 생성하여 화면에 그리라는 명령이 있어야 함을 03유닛에서 체득.
2. **04유닛 2발 발사 후 영구 발사 불가 버그**
   - 증상: 화면 밖으로 총알이 날아갔는데 스페이스바를 눌러도 총알이 다시는 나가지 않음.
   - 원인: 화면 밖으로 나갔을 뿐 메모리와 스프라이트 그룹 바구니 안에 계속 남아있어 `len < 2` 조건에 걸림.
   - 해결: 04-C 단계에서 `if self.rect.bottom < 0: self.kill()`을 도입하여 화면 밖 객체를 그룹에서 소멸시킴으로써 완벽 해결.
3. **06유닛 적 탄환 비교 연산자 오류 진단**
   - 흔한 실수: `if self.rect.top > 0: self.kill()` 작성 시 발사 1프레임 만에 즉시 소멸.
   - 해결: 06-C 단계에서 부등호와 좌표계를 대조하여 `if self.rect.top > SCREEN_HEIGHT: self.kill()`로 바닥 탈출 판정 교정.
4. **08유닛 방어선 침범 후 연쇄 기체 감소 및 사이렌 연속 발생**
   - 증상: 적이 방어선을 뚫은 뒤에도 계속 아래로 기어가며 경보음이 멈추지 않고 생명이 0이 됨.
   - 해결: 09유닛에서 `check_game_status`를 통해 탄환을 비우고 적들을 원래 고향 좌표(`starting_x`, `starting_y`)로 일괄 리셋하여 완벽 해결.
5. **09유닛 원본의 동기 무한 대기 루프(`while is_paused:`) 브라우저 프리징 문제**
   - 증상: 데스크톱용 중첩 루프 코드를 브라우저에서 실행하면 탭이 굳고 응답 없음으로 크래시됨.
   - 해결: 09-A 단계에서 최상위 메인 루프를 유지하면서 `mission.state = 'paused'`와 `Enter` 키로 update만 쉬어가는 현대적인 상태 머신 패턴으로 개선.

---

## 4. 검증 결과 및 미검증 항목의 명확한 구분

### 실제로 실행하여 통과한 검증 항목
1. **Python 문법 및 AST 파싱 검증 (100% 통과)**
   - `draft/checkpoints/` 안의 모든 24개 `.py` 파일에 대해 `ast.parse()` 검증을 자동 수행하였으며, 단 하나의 문법 오류(SyntaxError, IndentationError) 없이 100% 정상 파싱됨을 확인했습니다.
2. **JSON 파싱 및 스키마 구조 검증 (100% 통과)**
   - `draft/manifest.json`: 총 10개 유닛, 24개 체크포인트 연결 관계 파싱 완료.
   - `draft/assessments.json`: 총 10개 유닛, 29개 Code Trace 연습문제, 정확히 100개의 객관식 퀴즈(유닛당 10개) 파싱 완료.
3. **퀴즈 및 평가 데이터 정합성 검증 (100% 통과)**
   - 100개 퀴즈 전 문항이 4지 선다형이며 정확히 1개의 `isCorrect: true`를 포함함을 확인.
   - 정답 인덱스(0, 1, 2, 3)가 각 유닛별로 균형 있게 분산(3, 3, 2, 2)되어 특정 번호 쏠림이 없음을 확인.
   - 정답 해설에 정답의 근거와 3개 오답이 틀린 이유가 모두 서술되어 있음을 확인.
   - 미학습 개념(선수 지식 위반) 출제 여부 검토 완료: 각 유닛의 퀴즈는 해당 유닛 및 이전 유닛에서 배운 내용만으로 해결 가능하도록 엄격히 통제됨.
4. **에셋 경로 및 파일 실재 여부 대조 (100% 일치)**
   - 코드에 등장하는 9대 에셋 파일 경로가 실제 `public/space-invaders/`에 완벽히 존재함을 확인:
     - `assets/scout.png` (존재)
     - `assets/raider.png` (존재)
     - `assets/DoHyeon-Regular.ttf` (존재)
     - `assets/scout_pulse.ogg`, `raider_pulse.ogg`, `raider_break.ogg`, `shield_hit.ogg`, `line_alert.ogg`, `wave_ready.ogg` (6종 모두 존재)
5. **수정 블록의 누적 적용 정합성 검증 (100% 일치)**
   - `data-log/01.md`부터 `10.md`까지 단계별로 안내된 추가/교체 코드를 순서대로 적용했을 때 해당 단계의 체크포인트 `.py` 코드와 토큰 단위로 정확히 일치함을 확인.

### 미실행 검증 및 사유 (솔직한 보고)
1. **메타센스 게임 스튜디오 실시간 브라우저 실행 검증**
   - 사유: 본 에이전트(Antigravity)는 교육 콘텐츠 집필자로서 `draft/` 디렉터리와 보고서 파일에만 쓰기 권한이 제한되어 있으며, 운영 계정 로그인 브라우저 자동화 도구를 임의로 조작하지 않는 안전 수칙을 준수했습니다. 실제 스튜디오 웹 런타임에서의 플레이어 조작 및 프레임 테스트는 통합 담당자인 Codex의 단계로 인계합니다.
2. **실시간 2인 Quiz Battle 라이브 소켓 대전 검증**
   - 사유: 현재 메타센스 앱 아키텍처 상 Quiz Battle은 동일한 `quizzes` 문제은행을 공유하여 작동하므로 문제은행 데이터 정합성은 검증되었으나, 실제 두 브라우저 간의 동시 소켓 배틀 플레이는 Codex의 통합 테스트 단계에서 검증되어야 합니다.
3. **스피커를 통한 실제 6종 오디오의 청각적 감상**
   - 사유: 사운드 파일의 길이, 파형 생성 스크립트, pygame.mixer.Sound 로딩 문법 및 재생 함수 호출은 정적 분석으로 완벽히 확인하였으나, 인간의 귀로 직접 사운드를 듣는 청음 검사는 수행하지 않았습니다.

---

## 5. Codex 통합 시 필요한 사항 안내

1. **커리큘럼 등록 위치**:
   - `regionId`: `reg_python_game_project`
   - Data Log 원고는 `units.learningContents.text`에 매핑하고 `contentFlags.hasDataLog = True`로 설정.
   - 동영상 없음 정책에 따라 `transmissions = []`, `videoConfig.videoId = ''`, `hasTransmission = False` 유지.
2. **평가 데이터 등록**:
   - `draft/assessments.json`의 `exercises`는 `unit.codeExercises`로, `quizzes`는 `unit.quizzes`로 등록하면 기존 시스템과 100% 호환됩니다.
3. **스튜디오 수업 준비 버튼 및 에셋**:
   - 이미 Codex가 구현해 둔 '우주 방어대 수업 준비' 버튼이 프로젝트 생성 시 `assets/` 9개 파일과 `asset_credits.py`, 빈 `main.py`를 올바르게 공급하므로, 본 커리큘럼 초안과 완벽하게 맞물려 작동합니다.
